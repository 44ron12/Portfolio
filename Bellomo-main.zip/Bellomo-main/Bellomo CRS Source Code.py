import os
import re
import pandas as pd
from tkinter import ttk, Tk
import customtkinter as ctk
from tkinter.filedialog import asksaveasfilename
from tkinter.messagebox import showerror, showinfo, askyesnocancel
from tkinter.filedialog import askopenfilename
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from PIL import Image, ImageTk
import webbrowser



# Global Values
file_list = []
sorted_file = {}
save_file = {}
entry = []
file_opened = ''
fileIsOpen = False
text = ''
selected = ''


class ExcellSorter:  
    def __init__(self, name): 
        self.name = name

        global fileIsOpen

        # Create GUI
        self.app = ctk.CTk()
        ctk.set_default_color_theme("blue")
        self.app.title(self.name)
        self.app.geometry('675x400')
        self.center_window(self.app,675,400)
        self.app.iconbitmap("d:\\casti\\Bellomo\\opto.ico")
        self.app.resizable(False, False)

        # Interface Creation
        frame_1 = ctk.CTkFrame(self.app, width=150, height=385, corner_radius=7, border_width=3, border_color='#111E90', fg_color="white")
        frame_1.grid(column=0, row=0, sticky='w', padx=10, pady=5)
        frame_1.grid_propagate(False)

        frame_2 = ctk.CTkFrame(self.app, width=490, height=40, corner_radius=7, border_width=3, border_color='#111E90', fg_color="white")
        frame_2.grid(column=1, row=0, sticky='nw', pady=7, padx=0)
        frame_2.grid_propagate(False)


        pil_image = Image.open(r"d:\casti\Bellomo\4.png")
        self.image_1 = ctk.CTkImage(pil_image,size=(130, 75))
        self.image_label_1 = ctk.CTkLabel(frame_1, image=self.image_1, font=("Callibri", 1), text="")
        self.image_label_1.grid(sticky="s", row=7, padx=7, pady=(65,0))

        
        # Buttons
        self.button1 = ctk.CTkButton(frame_1, text="Open", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.continue_cancel)
        self.button1.grid(sticky="n", row=0, padx=7, pady=(10,0))

        self.button2 = ctk.CTkButton(frame_1, text="Sort", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.sort_true)
        self.button2.grid(sticky="n", row=1, padx=7, pady=(5,0))
        
        self.button3 = ctk.CTkButton(frame_1, text="Toggle", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.toggle)
        self.button3.grid(sticky="n", row=2, padx=7, pady=(5,0))

        self.button4 = ctk.CTkButton(frame_1, text="Save", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.save_sort_data)
        self.button4.grid(sticky="n", row=3, padx=7, pady=(5,0))

        self.button5 = ctk.CTkButton(frame_1, text="About", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.about)
        self.button5.grid(sticky="n", row=4, padx=7, pady=(5,0))

        self.button6 = ctk.CTkButton(frame_1, text="Help", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.help)
        self.button6.grid(sticky="n", row=5, padx=7, pady=(5,0))

        self.button7 = ctk.CTkButton(frame_1, text="Exit", font=('Century Gothic', 12), width=135, corner_radius=3, fg_color='#111E90', command=self.exit_app)
        self.button7.grid(sticky="n", row=6, padx=7, pady=(5,0))

        # Label
        self.Label_1 = ctk.CTkLabel(frame_2, text=" "*6 +" - "*23+" "*5, font=("Century Gothic", 15), anchor="e", justify='right')
        self.Label_1.grid(sticky='w', pady=(7,0), padx=(12,0), row=0)
    
        self.Label_2 = ctk.CTkLabel(frame_2, text="|", font=("Century Gothic", 18))
        self.Label_2.place(x=360, y=5)

        self.Label_3 = ctk.CTkLabel(frame_2, text="None Selected", font=("Century Gothic", 15),  justify="right")
        self.Label_3.place(x=370, y=7)

        self.text_box = ctk.CTkTextbox(self.app, wrap="none", width=490, height=335, corner_radius=7, border_width=3, border_color="#111E90", fg_color="white")
        self.text_box.grid(column=1, row=0, sticky='sw', pady=5, padx=0)

        self.text_box.configure(state=ctk.DISABLED)


        self.bind_hover_events()

        self.app.mainloop()


    #FUNCTIONS

    def exit_app(self):
        self.app.destroy()

    # Function for Button Hover
    def bind_hover_events(self):
        self.button1.bind("<Enter>", lambda e: self.on_enter(e, self.button1))
        self.button1.bind("<Leave>", lambda e: self.on_leave(e, self.button1))
        self.button2.bind("<Enter>", lambda e: self.on_enter(e, self.button2))
        self.button2.bind("<Leave>", lambda e: self.on_leave(e, self.button2))
        self.button3.bind("<Enter>", lambda e: self.on_enter(e, self.button3))
        self.button3.bind("<Leave>", lambda e: self.on_leave(e, self.button3))
        self.button4.bind("<Enter>", lambda e: self.on_enter(e, self.button4))
        self.button4.bind("<Leave>", lambda e: self.on_leave(e, self.button4))
        self.button5.bind("<Enter>", lambda e: self.on_enter(e, self.button5))
        self.button5.bind("<Leave>", lambda e: self.on_leave(e, self.button5))
        self.button6.bind("<Enter>", lambda e: self.on_enter(e, self.button6))
        self.button6.bind("<Leave>", lambda e: self.on_leave(e, self.button6))
        self.button7.bind("<Enter>", lambda e: self.on_enter(e, self.button7))
        self.button7.bind("<Leave>", lambda e: self.on_leave(e, self.button7))

    def on_enter(self, event, button):
        button.configure(text_color='#111E90', fg_color="white")

    def on_leave(self, event, button):
        button.configure(text_color='white', fg_color='#111E90')

    # Function for continue-cancel pop-up
    def continue_cancel(self):
        try:
            global fileIsOpen
            if fileIsOpen is False:
                self.openfile()
            else:
                msg_box = askyesnocancel("A file has already been selected", "Select Another File?", icon="question")
                if msg_box:
                    self.openfile()
                if msg_box is False:
                    fileIsOpen = False
                if msg_box is None:
                    fileIsOpen = False
        
        except Exception:
            showerror("Error", "Something went wrong")
            return
        
    # Function that changes the text
    def change_text(self, new_text, label):
        label.configure(text=new_text)
    
    # Function to center the window of the application
    def center_window(self, window, width, height):
        screen_width = self.app.winfo_screenwidth()
        screen_height = self.app.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        window.geometry(f'{width}x{height}+{x}+{y}')

    # Function that adds items into a dictionary
    def add_dictionary(self, dictionary, key, tor):
        dictionary[key] = tor
    

    def sort_false(self):
        self.sort(tof=False)
      

    def sort_true(self):
        self.sort(tof=True)

    # Function for opening files
    def openfile(self):  
            try:
                global file_opened, fileIsOpen, entry

                file_path = askopenfilename(title="Open File", filetypes=[("Excel Files", ".xls .xlsx .csv")])
                if file_path is False:
                    fileIsOpen = False
                if file_path is None:
                    file_path = False
                if file_path:   
                    if file_path in entry:
                        showerror("Error", "File has already been selected")  
                        pass
                    else:
                        file_list.append(file_path)
                        

                        file_opened = file_path
                        fileIsOpen = True
                        
                        self.display_text(file_opened)

                        base_name = os.path.basename(file_path) 
                        self.change_text(base_name, self.Label_1)
                        
                        if fileIsOpen is True:
                            self.change_text("      Selected    ", self.Label_3)

                        self.add_dictionary(save_file, file_path, False)
                        entry.append(file_path)

            except FileNotFoundError:
                showerror("Error", "No file found")
            except Exception as e:
                showerror("Error", f"File not applicable\nError:{e}")
                fileIsOpen = False
            
    def sort(self, tof):
        global fileIsOpen, file_opened, save_file

        control = tof

        if fileIsOpen is False:
            showerror("Error", "No file opened")
            return

        if not file_opened:
            showerror("Error", "No file found")
            return

        for name, tor in save_file.items():
            if file_opened == name:
                if tor is False:
                    file_path = file_opened
                    file_extension = file_path.split('.')[-1]

                    if file_extension in ['xls', 'xlsx']:
                        file = pd.read_excel(file_path)
                    elif file_extension == 'csv':
                        file = pd.read_csv(file_path)
                    else:
                        showerror("Error", "Unsupported file type")
                        return

                    print("Actual columns in the file:", file.columns.tolist())

                    file.columns = file.columns.str.strip().str.lower()

                    column_mapping = {
                        'date & time': 'Date & Time',
                        'contact phone': 'Contact Phone',
                        'number name': 'Number Name'
                    }

                    columns = [key for key in column_mapping.keys() if key in file.columns]
                    missing_columns = [key for key in column_mapping.keys() if key not in file.columns]

                    if len(columns) != len(column_mapping):
                        raise KeyError(f"Missing columns: {', '.join(missing_columns)}")

                    file = file[columns]
                    file.rename(columns=column_mapping, inplace=True)
                    file.sort_values("Number Name", ascending=True, inplace=True, na_position='first')
                    filess = file.to_csv(sep="\t", index=False, header=None)

                    Header_1 = "        Date & Time         | Contact Phone |      Number Name     \n"
                    Header_2 = "-" * 142 + '\n'
                    Header_3 = "\n" + "=" * 63 + '\n\n' + 'SUMMARY \n\n' + 'No. | Number Name ' + "\n" + "-" * 142

                    filess = filess.replace('\t', '  |  ')

                    counters = {
                        'Referral Traffic': 0,
                        'Social Media': 0,
                        'SEO/Organic': 0,
                        'York Google Listing': 0,
                        'Podcast': 0,
                        'Local Service Ads': 0,
                        'Lancaster Google Listing': 0,
                        'Internet-Direct': 0,
                        'Google Ads/PPC': 0,
                        'Facebook Ads': 0,
                        'Direct Mail Marketing': 0,
                        'York Dance Program': 0,
                        'Lancaster EMS': 0,
                        'Billboard specs': 0,
                        'Beyond50 Resource Directory': 0,
                        'Caregiver Solutions': 0,
                        'Alz Lancaster/Harrisburg Insert': 0,
                        'Universal Athletics Club': 0,
                        'Lancaster Chamber': 0,
                        'Wine Dinner Ad / Wine in the Gardens': 0,
                        '50+ Life Print ad': 0,
                        'Heritage Senior Center': 0,
                        'Beyond 50 York County Resource Director': 0,
                        'Yelp': 0
                    }

                    uncounters = {}
                    total = 0

                    for name in file["Number Name"]:
                        if name in counters:
                            counters[name] += 1
                            total += 1
                        else:
                            uncounters[name] = uncounters.get(name, 0) + 1
                            total += 1

                    self.add_dictionary(save_file, file_path, True)

                    self.text_box.configure(state=ctk.NORMAL)
                    self.text_box.delete(1.0, ctk.END)
                    self.text_box.insert(ctk.END, text=(Header_1 + Header_2 + filess + Header_3))
                    
                    for name, num in counters.items():
                        space = " " * (3 - len(str(num)))
                        self.text_box.insert(ctk.END, text=f'\n{space}{num}{space}: {name}')
                    
                    for name, num in uncounters.items():
                        space = " " * (3 - len(str(num)))
                        self.text_box.insert(ctk.END, text=f"\n{space}{num}{space}: {name}")
                    
                    self.text_box.insert(ctk.END, text=f"\n{'-'*142}\n Total = {total}")  
                    self.text_box.configure(state=ctk.DISABLED)

                    if control:
                        showinfo("Info", "File has been sorted")
                elif tor is True:
                    if control:
                        showinfo("Info", "File has already been sorted")
                return




    # Function for displaying text  
    def display_text(self, file):
        global fileIsOpen, file_opened

        if fileIsOpen is True:
            if file_opened:
                file_path = file
                file_extension = file_path.split('.')[-1]

                if file_extension in ['xls', 'xlsx']:
                    file = pd.read_excel(file_path)
                elif file_extension == 'csv':
                    file = pd.read_csv(file_path)
                else:
                    showerror("Error", "Unsupported file type")
                    return
                    
                file.columns = file.columns.str.strip().str.lower()

                column_mapping = {
                    'date & time': 'Date & Time',
                    'contact phone': 'Contact Phone',
                    'number name': 'Number Name'
                }

                columns = []
                for key, value in column_mapping.items():
                    if key in file.columns:
                        columns.append(value)
                    else:
                        raise KeyError(f"'{value}' column not found in the file")

                files = file[list(column_mapping.keys())]
                filess = files.to_csv(sep="\t", index=False, header=None)

                Header_1 = "        Date & Time         | Contact Phone |      Number Name     \n"
                Header_2 = "-"*142 + '\n'
                
                filess = filess.replace('\t', '  |  ')
                
                self.text_box.configure(state=ctk.NORMAL)
                self.text_box.delete(1.0, ctk.END)
                self.text_box.insert(ctk.END, text=(Header_1 + Header_2 + filess))
                self.text_box.configure(state=ctk.DISABLED)

    
    def toggle(self):
        if fileIsOpen is True:    
            global save_file, entry

            self.toggle_win = ctk.CTkToplevel(self.app, fg_color="white")
            ctk.set_default_color_theme("blue")
            self.toggle_win.title(self.name)
            self.center_window(self.toggle_win, 400, 250)
            self.toggle_win.transient(self.app)
            self.toggle_win.resizable(False, False)
            self.toggle_win.attributes("-topmost", True)
            self.toggle_1 = ctk.CTkFrame(self.toggle_win, width=391, height=200, border_width=3, border_color='#111E90', fg_color='white')
            self.toggle_1.grid(sticky='n', row=0, padx=(5, 0), pady=(3, 0))
            self.toggle_1.grid_propagate(False)
            self.toggle_2 = ctk.CTkFrame(self.toggle_win, width=391, height=40, fg_color='white')
            self.toggle_2.grid(sticky='n', row=1, padx=(5, 0), pady=(3, 0))
            self.toggle_2.grid_propagate(False)

            self.checkbox_vars = []
            self.print = []

            for num, name in enumerate(entry):
                var = ctk.IntVar()
                base_name = os.path.basename(name)
                check_box = ctk.CTkCheckBox(self.toggle_1, variable=var, text=base_name, command=lambda var=var: self.check_box_counter(var))
                check_box.grid(sticky='w', column=0, row=num, padx=(7, 0), pady=(7, 0))
                self.checkbox_vars.append((var, base_name, name, check_box))

            self.button_1 = ctk.CTkButton(self.toggle_2, text="Select", width=100, height=30, border_width=3, fg_color='#111E90', border_color='#111E90', 
                                        command=self.display_toggle)
            self.button_1.grid(sticky='e',column=4, row=0, pady=(7))

            self.button_2 = ctk.CTkButton(self.toggle_2, text="Remove", width=100, height=30, border_width=3, fg_color='#111E90', border_color='#111E90', 
                                        command=self.delete_toggle)
            self.button_2.grid(sticky='e', column=3, row=0,padx=(185,5), pady=(7))

            self.toggle_win.mainloop()
        else:
            showerror("Error", "No file found")
            
    def check_box_counter(self, selected_var):
        global selected
        
        if selected_var.get() == 1:
            selected = selected_var
            for var, _, __, widget in self.checkbox_vars:
                if var != selected_var:
                    var.set(0) 


    def delete_toggle(self):
        global selected, fileIsOpen, file_opened

        for var, base_name, name, widget in self.checkbox_vars:
            if var == selected:
                widget.destroy()
                for og_name in entry:
                    if og_name == name:
                        entry.remove(og_name) 

                if self.Label_1.cget("text") == str(base_name):
                    self.change_text("None Selected", self.Label_3)
                    self.change_text(" "*6 +" - "*23+" "*5, self.Label_1)
                    self.text_box.configure(state=ctk.NORMAL)
                    self.text_box.delete("1.0", ctk.END)
                    self.text_box.configure(state=ctk.DISABLED)
                    if len(self.checkbox_vars) == 1:
                        self.toggle_win.destroy() 

                self.checkbox_vars.remove((var, base_name, name, widget))
                
                if len(self.checkbox_vars) == 0: 
                    self.toggle_win.destroy() 
                    self.change_text("None Selected", self.Label_3)
                    self.change_text(" "*6 +" - "*23+" "*5, self.Label_1)
                    self.text_box.configure(state=ctk.NORMAL)
                    self.text_box.delete("1.0", ctk.END)
                    self.text_box.configure(state=ctk.DISABLED)
                    file_opened = None
                    fileIsOpen = False

    def display_toggle(self):
        global selected, file_opened
        

        for index, (var, i, j, widget) in enumerate(self.checkbox_vars):
            if var == selected:
                for key, tor in save_file.items():
                    if key == j:
                        file_opened = j
                        if tor is True:
                            self.add_dictionary(save_file, key, False)
                            self.sort_false()
                            self.change_text(i, self.Label_1)
                            self.toggle_win.destroy() 
                        else:
                            self.display_text(j)
                            self.change_text(i, self.Label_1)
                            self.toggle_win.destroy()
                

    # Function for sorting data
    def save_sort_data(self):
        global file_opened, fileIsOpen

        if fileIsOpen is True:
            try:            
                counters = {
                    'Referral Traffic': 0,
                    'Social Media': 0,
                    'SEO/Organic': 0,
                    'York Google Listing': 0,
                    'Podcast': 0,
                    'Local Service Ads': 0,
                    'Lancaster Google Listing': 0,
                    'Internet-Direct': 0,
                    'Google Ads/PPC': 0,
                    'Facebook Ads': 0,
                    'Direct Mail Marketing': 0,
                    'York Dance Program': 0,
                    'Lancaster EMS': 0,
                    'Billboard specs': 0,
                    'Beyond50 Resource Directory': 0,
                    'Caregiver Solutions': 0,
                    'Alz Lancaster/Harrisburg Insert': 0,
                    'Universal Athletics Club': 0,
                    'Lancaster Chamber': 0,
                    'Wine Dinner Ad / Wine in the Gardens': 0,
                    '50+ Life Print ad': 0,
                    'Heritage Senior Center': 0,
                    'Beyond 50 York County Resource Director': 0,
                    'Yelp': 0
                }

                uncounters = {}

                if not file_opened:
                    showerror("Error", "No file opened")
                    return

                for name, tor in save_file.items():
                    if name == file_opened:
                        if tor is True:
                            file_path = file_opened
                            file_extension = file_path.split('.')[-1]

                            if file_extension in ['xls', 'xlsx']:
                                file = pd.read_excel(file_path)
                            elif file_extension == 'csv':
                                file = pd.read_csv(file_path)
                            else:
                                showerror("Error", "Unsupported file type")
                                return
                            
                            file.columns = file.columns.str.strip().str.lower()

                            column_mapping = {
                                'date & time': 'Date & Time',
                                'contact phone': 'Contact Phone',
                                'number name': 'Number Name'
                            }

                            columns = []
                            for key, value in column_mapping.items():
                                if key in file.columns:
                                    columns.append(key)
                                else:
                                    raise KeyError(f"'{value}' column not found in the file")

                            file = file[columns]
                            file.rename(columns=column_mapping, inplace=True)
                            file.sort_values("Number Name", ascending=True, inplace=True, na_position='first')

                            for name in file["Number Name"]:
                                if name in counters:
                                    counters[name] += 1
                                else:
                                    uncounters[name] = 0

                            for name in file["Number Name"]:
                                if name in uncounters:
                                    uncounters[name] += 1

                            data_for_excel = []
                            for name, count in counters.items():
                                if count > 0:
                                    filtered_data = file[file["Number Name"] == name]
                                    times = sorted(filtered_data['Date & Time'].tolist(), reverse=True)
                                    numbers = filtered_data['Contact Phone'].tolist()
                                    for time, number in zip(times, numbers):
                                        data_for_excel.append([name, time, number])

                            df = pd.DataFrame(data_for_excel, columns=['Category', 'Date & Time', 'Number'])

                            wb = Workbook()
                            ws = wb.active
                            ws.title = 'Sheet1'

                            col = 1
                            for category in counters.keys():
                                if counters[category] > 0:
                                    ws.merge_cells(start_row=1, start_column=col, end_row=1, end_column=col+1)
                                    cell = ws.cell(row=1, column=col)
                                    cell.value = category
                                    cell.alignment = Alignment(horizontal='center', vertical='center')
                                    ws.cell(row=2, column=col, value='Date & Time')
                                    ws.cell(row=2, column=col+1, value='Number')
                                    col += 2

                            row = 3
                            col = 1
                            for category in counters.keys():
                                if counters[category] > 0:
                                    filtered_data = file[file["Number Name"] == category]
                                    filtered_data = filtered_data.sort_values(by='Date & Time', ascending=False)
                                    for _, data_row in filtered_data.iterrows():
                                        ws.cell(row=row, column=col, value=data_row['Date & Time'])
                                        ws.cell(row=row, column=col+1, value=data_row['Contact Phone'])
                                        row += 1

                                    total_row = row
                                    ws.cell(row=total_row, column=col, value='Total')
                                    ws.cell(row=total_row, column=col+1, value=counters[category])
                                    total_font = Font(bold=True)
                                    ws.cell(row=total_row, column=col).font = total_font
                                    ws.cell(row=total_row, column=col+1).font = total_font

                                    col += 2
                                    row = 3

                            summary_start_col = col + 1
                            ws.cell(row=1, column=summary_start_col, value='Summary')
                            ws.cell(row=1, column=summary_start_col).font = Font(bold=True)
                            for i, (category, count) in enumerate(counters.items(), start=2):
                                ws.cell(row=i, column=summary_start_col, value=category)
                                ws.cell(row=i, column=summary_start_col + 1, value=count)

                            ws.cell(row=26, column=summary_start_col, value='Others')
                            ws.cell(row=26, column=summary_start_col).font = Font(bold=True)
                            for j, (category, count) in enumerate(uncounters.items(), start=27):
                                ws.cell(row=j, column=summary_start_col, value=category)
                                ws.cell(row=j, column=summary_start_col + 1, value=count)

                            self.save_file(wb)

                        else:
                            showerror("Error", "File is not yet sorted")

            except FileNotFoundError:
                showerror("Error", "No file found")
            except KeyError as e:
                showerror("Error", f"File is missing expected columns: {e}")
            except Exception as e:
                showerror("Error", f"An unexpected error occurred: {e}")
        else:
            showerror("Error", "No file found")


    # Function for saving file
    def save_file(self, wb, filename=None):

        global fileIsOpen
        
        if fileIsOpen is True:
            filetypes = [('Excel files', '*.xlsx'), ('CSV files', '*.csv')]
            if filename is None:
                filename = asksaveasfilename(initialfile='Call-Report(Results)' ,defaultextension='.xlsx', filetypes=filetypes)

            if not filename:
                return

            base, extension = os.path.splitext(filename)
            
            counter = 1
            
            unique_filename = filename
            while os.path.exists(unique_filename):
                unique_filename = f"{base}_{counter}{extension}"
                counter += 1
            
            if extension == ".xlsx":
                wb.save(unique_filename)
            elif extension == ".csv":
                sheet = wb.active
                data = sheet.values
                df = pd.DataFrame(data)
                df.to_csv(unique_filename, index=False)
        
            showinfo("Notification", "File was saved successfully")

        else:
            showinfo("Error", "No file opened")

    def open_hyperlink(self, url):
        webbrowser.open_new(url)

    def about(self):   
        global save_file, entry

        self.about_win = ctk.CTkToplevel(self.app, fg_color="white")
        ctk.set_default_color_theme("blue")
        self.about_win.title("OptoGrow - About")
        self.center_window(self.about_win, 400, 300)
        self.about_win.transient(self.app)
        self.about_win.resizable(False, False)
        self.about_win.attributes("-topmost", True)

        self.frame_1 = ctk.CTkFrame(self.about_win, width=391, height=40, fg_color='white')
        self.frame_1.grid(sticky='n', row=0, padx=(5, 0), pady=(3, 0))
        self.frame_1.grid_propagate(False)
        
        self.text_1 = ctk.CTkLabel(self.frame_1, text="Bellomo Call Report Sorter Application", font=("Century Gothic", 18, 'bold'), justify='center', text_color='#111E90')
        self.text_1.grid(row=0, sticky="nsew", padx=(30, 0))

        self.text_2 = ctk.CTkLabel(self.frame_1, text="¯" * 45, font=("Century Gothic", 14), justify='center', text_color='#111E90')
        self.text_2.grid(row=1, sticky="nsew", padx=(30, 0))

        self.frame_2 = ctk.CTkFrame(self.about_win, width=391, height=170, fg_color='white')
        self.frame_2.grid(sticky='w', row=1, padx=(5, 0), pady=(3, 0))
        self.frame_2.grid_propagate(False)

        self.text_3 = ctk.CTkLabel(self.frame_2, text="Developed for:", font=("Century Gothic", 15), justify='center', text_color='#111E90', wraplength=350)
        self.text_3.grid(row=0, sticky="nw", padx=(30, 0))

        image_2 = ctk.CTkImage(Image.open("OpTo.png"), size=(100, 90))
        label_2 = ctk.CTkLabel(self.frame_2, image=image_2, text="OptoGrow Operations\nManagement Services", compound='top', cursor="hand2")
        label_2.grid(column=0, row=1, sticky="n", padx=(35,0), pady=(15,0))
        label_2.bind("<Button-1>", lambda e: self.open_hyperlink("https://www.optogrow.com"))

        image = ctk.CTkImage(Image.open("4.png"), size=(110, 100))
        label = ctk.CTkLabel(self.frame_2, image=image, text="Bellomo & Associates LLC", compound='top', cursor="hand2")
        label.grid(column=2, row=1, sticky="n", padx=(50,0), pady=(15,0))

        label.bind("<Button-1>", lambda e: self.open_hyperlink("https://www.bellomoassociates.com"))

        self.frame_3 = ctk.CTkFrame(self.about_win, width=391, height=10, fg_color='white')
        self.frame_3.grid(sticky='n', row=2, padx=(5, 0), pady=(3, 0))
        self.frame_3.grid_propagate(False)
        
        self.text_5 = ctk.CTkLabel(self.frame_3, text="¯" * 45, font=("Century Gothic", 14), justify='center', text_color='#111E90')
        self.text_5.grid(row=2, sticky="nsew", padx=(30, 0))

        self.frame_4 = ctk.CTkFrame(self.about_win, width=391, height=100, fg_color='white')
        self.frame_4.grid(sticky='n', row=3, padx=(5, 0), pady=(3, 0))
        self.frame_4.grid_propagate(False)

        image_Aaron = ctk.CTkImage(Image.open("Aaron.png"), size=(135, 25))
        label_Aaron = ctk.CTkLabel(self.frame_4, image=image_Aaron, text="Developer", font=("Century Gothic", 14), compound='top', cursor="hand2")
        label_Aaron.grid(column=0, row=0, sticky="n", padx=(30,0), pady=(7,0))

        image_Fran = ctk.CTkImage(Image.open("Fran.png"), size=(159, 25))
        label_Fran = ctk.CTkLabel(self.frame_4, image=image_Fran, text="Supervisor", font=("Century Gothic", 14), compound='top', cursor="hand2")
        label_Fran.grid(column=1, row=0, sticky="n", padx=(30,0), pady=(8,0))

        self.app.mainloop()
    
    def help(self):
        help_window = ctk.CTkToplevel(self.app, fg_color="white")
        ctk.set_default_color_theme("blue")
        help_window.title("OptoGrow - Help")
        self.center_window(help_window, 500, 400)
        help_window.transient(self.app)
        help_window.resizable(True, True)

        self.frame_1 = ctk.CTkFrame(help_window, width=391, height=40, fg_color='white')
        self.frame_1.grid(sticky='n', row=0, padx=(5, 0), pady=(3, 0))
        self.frame_1.grid_propagate(False)
        
        self.text_1 = ctk.CTkLabel(self.frame_1, text="Help Window", font=("Century Gothic", 18, 'bold'), justify='center', text_color='#111E90')
        self.text_1.grid(row=0, sticky="nsew", padx=(30, 0))

        self.text_2 = ctk.CTkLabel(self.frame_1, text="¯" * 45, font=("Century Gothic", 14), justify='center', text_color='#111E90')
        self.text_2.grid(row=1, sticky="nsew", padx=(30, 0))

        self.frame_2 = ctk.CTkFrame(help_window, width=491, height=265, fg_color='white')
        self.frame_2.grid(sticky='w', row=1, padx=(5, 0), pady=(3, 0))
        self.frame_2.grid_propagate(False)
        
        label_z = ctk.CTkLabel(self.frame_2, text="Application Manual", font=("Century Gothic", 15, 'bold'), justify='center', text_color='#111E90')
        label_z.grid(column=0, row=0, padx=30, pady=(5,0), sticky='nsew')

        label_b = ctk.CTkLabel(self.frame_2, text="•  OPEN - this will let the user open the spreadsheet file (Csv or Xlss) to be use.", font=("Arial", 13))
        label_b.grid(column=0, row=1, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="•  SORT - this will sort the current selected spreadsheet file.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=2, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="• TOGGLE - this will let the user to toggle between the files opened in the app.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=3, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="•  SAVE - this will let the user to save the sorted data into a spreadsheet file.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=4, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="•  ABOUT - this will open the about window that has information about this app.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=5, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="•  HELP - this will open the help window that short manual and bug report function.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=6, padx=20, pady=(2,0), sticky='w')

        label_c = ctk.CTkLabel(self.frame_2, text="•  EXIT - this will let the user close the program.",
                        font=("Arial", 13))
        label_c.grid(column=0, row=7, padx=20, pady=(2,0), sticky='w')

        self.text_0 = ctk.CTkLabel(self.frame_2, text="¯" * 45, font=("Century Gothic", 14), justify='center', text_color='#111E90')
        self.text_0.grid(row=8, padx=(77,0), pady=(2,0), sticky='w')

        frame_3 = ctk.CTkFrame(help_window, width=500, height=30, fg_color='white')
        frame_3.grid(sticky='n', row=2)
        frame_3.grid_propagate(False)

        label_z = ctk.CTkLabel(frame_3, text="Contacts", font=("Century Gothic", 15, 'bold'), justify='center', text_color='#111E90')
        label_z.grid(column=1, row=0, padx=(200,0), sticky='nsew')

        frame_4 = ctk.CTkFrame(help_window, width=500, height=30, fg_color='white')
        frame_4.grid(sticky='n', row=3)
        frame_4.grid_propagate(False)

        email_1 = ctk.CTkLabel(frame_4, text="aaronpaul.optogrow@gmail.com", font=("Century Gothic", 13), justify='center', cursor="hand2")
        email_1.grid(column=0, row=0, padx=(54,0), sticky='w')
        email_1.bind("<Button-1>", lambda e: webbrowser.open("mailto:aaronpaul.optogrow@gmail.com"))

        Sep = ctk.CTkLabel(frame_4, text="|", font=("Century Gothic", 15), justify='center', text_color='#111E90')
        Sep.grid(column=1, row=0, padx=10, sticky='w')

        email_2 = ctk.CTkLabel(frame_4, text="team@optogrow.com", font=("Century Gothic", 13), justify='center', cursor="hand2")
        email_2.grid(column=2, row=0, sticky='w')
        email_2.bind("<Button-1>", lambda e: webbrowser.open("mailto:team@optogrow.com"))


        self.app.mainloop()


def open_book(excell_sorter):
    return excell_sorter

addressk = ExcellSorter("OptoGrow - Bellomo")


open_book(addressk)


