Bellomo Call Report Sorter
Developed for OptoGrow Operations Management Services & Bellomo & Associates LLC

A desktop GUI application built with Python and Tkinter, designed to help users open, sort, analyze, and export call report data from Excel or CSV files. The app categorizes incoming leads by source and generates formatted output for reporting.

Features
- Open Excel/CSV files — import call data with a clean GUI
- Sort and analyze — organize calls by "Number Name" and count their occurrences
- Toggle between files — view and manage multiple open datasets
- Save formatted results — export summary reports to .xlsx or .csv
- Summary generation — breakdown of both expected and unexpected lead sources
- Branded UI — includes logos and organization-specific theming
- About and Help windows — detailed manual and developer information

This repository includes:
- Zip file containing the The application executable and its build folder for Windows
- Application source code
- Folders of pictures used in the app
